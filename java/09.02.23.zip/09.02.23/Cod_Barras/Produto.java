package Cod_Barras;

import java.util.Scanner;

public class Produto {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        //receber código
        System.out.println("Digite o código do produto: ");
        int cod_prod = scanner.nextInt();

        // nome do produto
        // quantidade
        // valor unitário
        // área para qual será direcionado
        // detalhes específicos do produto


        String[] produto = {"nome", "quantidade"};



        // Mostrar as informações do produto

        // Valor total - quantidade * valor unitário

        // Status de envio para a área = true
    }
}

