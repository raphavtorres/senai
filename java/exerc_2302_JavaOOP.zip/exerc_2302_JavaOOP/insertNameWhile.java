import java.util.Scanner;

public class insertNameWhile {
    public static void main (String args[]){
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Insert a name: ");
            String name = scanner.nextLine();
            System.out.println("[0] Finalizar\n[1] Continuar");
            int resp = Integer.parseInt(scanner.nextLine());
//            scanner.nextLine();
            if (resp == 0){
                break;
            }
        }
    }
}
