public class numberDouble {
    public static void main (String args[]){

        for (int num = 0; num <= 100; num++) {
            int calc = num * 2;
            System.out.println(num + " x 2 = " + calc);

        }
    }
}
