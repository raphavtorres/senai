package product;

public class Product {
    public Product(String cod, String name, int quantity, float unitPrice, String area, String details, boolean status) {
        this.code = cod;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.area = area;
        this.details = details;
        this.status = status;
    }

    private String code;
    private String name;
    private int quantity;
    private float unitPrice;
    private String area;
    private String details;
    private boolean status;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(float unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public void infoCodProd(){
        System.out.println("=====================================================");
        System.out.println("Name: " + this.getName());
        System.out.println("Quantity: " + this.getQuantity());
        System.out.println("Unit price: " + this.getUnitPrice());
        System.out.println("Area: " + this.getArea());
        System.out.println("Details: " + this.getDetails());
        System.out.println("Status: " + this.showStatus());
        System.out.println("Total price: R$ " + this.totalValue());
        System.out.println("=====================================================\n\n");
    }

    public String showStatus(){
        if (this.getStatus() == true) {
            return "Sent to the area ";
        } else {
            return "Awaiting shipment to the area";
        }
    }
    public float totalValue(){
        return (this.getQuantity() * this.getUnitPrice());
    }
}
