package product;

import java.util.Locale;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main (String args[]){
        String answ;
        do {
            Product prod1 = new Product("001PN", "Pen", 100, 0.50F, "Senai Mange, Secretariat", "Blue pen", false);
            Product prod2 = new Product("002BK", "Book", 36, 50.68F, "Senai Mange, Class 10", "Portugue book", false);
            Product prod3 = new Product("003BG", "Bag", 10_000, 0.15F, "Carrefour, Campinas", "Plastic bag", true);

            ArrayList<Product> productsArray = new ArrayList<Product>();
            productsArray.add(prod1);
            productsArray.add(prod2);
            productsArray.add(prod3);


            Scanner scanner = new Scanner(System.in);

            System.out.print("Type the product's code: ");
            String codProd = scanner.next();

            for (Product prod : productsArray){
                if (codProd.equals(prod.getCode())){
                    prod.infoCodProd();
                } else {
                    System.out.println("No product found with this code...");
                    break;
                }
            }

            System.out.println("Do you want to check another product?: [yes] [no]");
            answ = scanner.next().toLowerCase();
        } while (answ.equals("yes"));

    }
}
