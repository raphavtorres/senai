temp_qnt = input("How many temperatures do you want to insert?: ")

temperatures = []
for i in temp_qnt:
    r_temp = input(f"Temperature {i}: ")
    temperatures.append(r_temp)
