print("######### DESAFIO – 01 ##########")

name = input("What's your name?: ")
print(f"Welcome, {name}!")
