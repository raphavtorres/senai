print("######### DESAFIO – 03 ##########")

num1 = int(input('First value: '))
num2 = int(input('Second value: '))
sum = num1 + num2
print(f'Result of the sum: {sum}')