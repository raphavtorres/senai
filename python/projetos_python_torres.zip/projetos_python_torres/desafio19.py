import math

print("######### DESAFIO – 19 ##########")

degree = int(input("Ângulo: "))
rad = math.radians(degree)

sin = math.sin(rad)
cos = math.cos(rad)
tan = math.tan(rad)

print(f"Sine: {sin} \nCosine: {cos} \nTangent: {tan}")
