from time import sleep
print("=====DESAFIO #04=====")

for i in range(10, -1, -1):
    print(i)
    sleep(1) # n preciso escrever "time.sleep()", pq importei especificamente o sleep, n time inteiro

print("🚀")