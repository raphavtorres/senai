print("=====DESAFIO #07=====")

print("-" * 20)
num = int(input("Digite um número: "))

for i in range(11):
    print(f"{num} x {i} = {num * i}")

print("-" * 20)
