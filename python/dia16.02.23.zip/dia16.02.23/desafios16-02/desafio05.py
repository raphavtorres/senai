print("=====DESAFIO #05=====")

print("-" * 73)
for i in range(50 + 1):
    if i % 2 == 0:
        print(i, end=" ")

print("\n" + "-" * 73)
