print("===== CONVERSOR DE BASES =====")
escolha = int(input("""Conversão a ser feita:
[0] - Decimal para binário
[1] - Binário para decimal
[2] - Hexadecimal para decimal
[3] - Hexadecimal para binário
[4] - Decimal para hexadecimal
[5] - Binário para hexadecimal"""))


def decBin():
    dec = int(input("Número para converter: "))
    dec

def binDec():
    pass


def hexDec():
    pass


def hexBin():
    pass


def decHex():
    pass


def binHex():
    pass


if escolha == 0:
    decBin()

if escolha == 1:
    binDec()

if escolha == 2:
    hexDec()

if escolha == 3:
    hexBin()

if escolha == 4:
    decHex()

if escolha == 5:
    binHex()
