palindromo = input("Digite valor para saber se é palindromo: ")
if palindromo[::-1] == palindromo:
    print("É palindromo!")
else:
    print("Não é palindromo!")
