nome = input("Digite seu nome: ")

# \033[style; text; back m

print(f"Seja bem-vindo \33[4;97;41m {nome} \33[ma escola")