print("######### DESAFIO – 13 ##########")

salary = float(input("Employee's salary: "))

salary += salary * 0.15

print(f"Salary with raise: {salary}")