print("######### DESAFIO – 02 ##########")

day = input("Day: ")
month = input("Month: ")
year = input("Year: ")

print(f"{day}/{month}/{year}")
