print("######### DESAFIO – 11 ##########")

height = float(input("height: "))
width = float(input("width: "))

area = height * width
liter = area / 2

print(f"You need {liter}L")