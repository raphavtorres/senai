print("######### DESAFIO – 08 ##########")

meters = int(input("Value in meters: "))
print(f"centimeters: {meters * 100} \nmillimeter: {meters * 1000}")
