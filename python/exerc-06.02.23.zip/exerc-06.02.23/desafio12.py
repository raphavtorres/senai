print("######### DESAFIO – 12 ##########")

price = float(input("Price: "))

# value_promotion = price - 0.05 * price
value_promotion = price * 0.95

print(f"New value: {value_promotion}")
