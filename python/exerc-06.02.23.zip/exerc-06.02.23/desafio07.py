print("######### DESAFIO – 07 ##########")

grade1 = int(input("Grade 1: "))
grade2 = int(input('Grade 2: '))

print(f"Average: {(grade1 + grade2) / 2}")
