print("######### DESAFIO – 05 ##########")

num = int(input("Number: "))

print(f"predecessor: {num - 1}, successor {num + 1}")
