import math

print("######### DESAFIO – 06 ##########")

num = int(input('Number: '))

print(f'{num} x 2: {num * 2}')
print(f'{num} x 3: {num * 3}')
print(f'√{num}: {math.sqrt(num)}')
