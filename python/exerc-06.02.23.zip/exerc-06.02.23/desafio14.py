import math

print("######### DESAFIO – 14 ##########")

num = float(input("Real number: "))

print(f"Whole portion: {math.ceil(num)}")