print("######### DESAFIO – 10 ##########")

real = int(input("How much money do you have on your wallet?(R$): "))

print(f"You can buy ${real / 5}")
