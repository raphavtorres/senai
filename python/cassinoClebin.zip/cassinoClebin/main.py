from random import randint
from threading import Timer
import os

def pararJogo(msg="\nTempo Acabou"):
    print(msg)
    pid = os.getpid()
    os.kill(pid, 0)


tempo = Timer(10.0, pararJogo)
tempo.start()

# sortear valor de 1 a 100
n_sorteado = randint(1, 100)

# Começa com 50 de vida
vida = 50

# 3 tentativas
tentativa = 1
while tentativa <= 3:
    print(f"Quantidade de vida: {vida}")
    n_user = int(input(f"Digite seu {tentativa} palpite: "))

    if n_user != n_sorteado:
        perde_vida = abs(n_sorteado - n_user)
        vida -= perde_vida
        if vida <= 0:
            pararJogo("VOCÊ PERDEU! Acabaram suas vidas...")
    else:
        pararJogo("Parabéns, você ganhou!")
    tentativa += 1

if vida > 0 and n_user != n_sorteado:
    pararJogo("VOCÊ PERDEU! Acabaram suas tentativas...")
